#!/usr/bin/env python3
"""
TikTok Bright Data System - API接続テスト
設定されたAPIキーの動作確認
"""

import os
import sys
import json
import time
import requests
from datetime import datetime

def load_config():
    """設定ファイルの読み込み"""
    try:
        with open("config.json", "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print("❌ config.json が見つかりません")
        print("   python config_setup_helper.py を実行して設定を作成してください")
        return None
    except json.JSONDecodeError as e:
        print(f"❌ config.json の形式が正しくありません: {e}")
        return None

def test_bright_data_connection(config):
    """Bright Data API接続テスト"""
    print("\n🔍 Bright Data API接続テスト")
    print("-" * 40)
    
    api_key = config["bright_data"]["api_key"]
    dataset_id = config["bright_data"]["dataset_id"]
    api_endpoint = config["bright_data"]["api_endpoint"]
    base_url = "https://api.brightdata.com/datasets/v3"
    
    # APIキー形式チェック
    if not api_key.startswith("bd_"):
        print("⚠️  APIキーの形式が正しくない可能性があります")
        print(f"   現在のAPIキー: {api_key[:10]}...")
        print("   正しい形式: bd_xxxxxxxxxx...")
    
    # 認証テスト
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    try:
        # データセット情報取得テスト
        url = f"{base_url}/datasets/{dataset_id}"
        print(f"📡 接続テスト: {url}")
        
        response = requests.get(url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            print("✅ API接続成功!")
            
            # データセット情報表示
            try:
                dataset_info = response.json()
                print(f"   データセット名: {dataset_info.get('name', 'N/A')}")
                print(f"   ステータス: {dataset_info.get('status', 'N/A')}")
                print(f"   最終更新: {dataset_info.get('last_updated', 'N/A')}")
            except:
                print("   データセット情報の解析に失敗しましたが、接続は成功しています")
            
            return True
            
        elif response.status_code == 401:
            print("❌ 認証エラー: APIキーが無効です")
            print("   - APIキーが正しく設定されているか確認してください")
            print("   - Bright Dataダッシュボードで新しいAPIキーを生成してください")
            return False
            
        elif response.status_code == 404:
            print("❌ データセットが見つかりません")
            print(f"   データセットID: {dataset_id}")
            print("   - TikTokスクレイパーが有効化されているか確認してください")
            return False
            
        else:
            print(f"❌ API接続エラー: HTTP {response.status_code}")
            print(f"   レスポンス: {response.text[:200]}...")
            return False
            
    except requests.exceptions.Timeout:
        print("❌ 接続タイムアウト")
        print("   - ネットワーク接続を確認してください")
        print("   - タイムアウト値を増加してください")
        return False
        
    except requests.exceptions.ConnectionError:
        print("❌ 接続エラー")
        print("   - インターネット接続を確認してください")
        print("   - プロキシ設定を確認してください")
        return False
        
    except Exception as e:
        print(f"❌ 予期しないエラー: {e}")
        return False

def test_sample_data_collection(config):
    """サンプルデータ収集テスト"""
    print("\n🧪 サンプルデータ収集テスト")
    print("-" * 40)
    
    api_key = config["bright_data"]["api_key"]
    dataset_id = config["bright_data"]["dataset_id"]
    api_endpoint = config["bright_data"]["api_endpoint"]
    base_url = "https://api.brightdata.com/datasets/v3"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    # サンプル収集リクエスト
    sample_request = {
        "url": "https://www.tiktok.com/discover",
        "format": "json",
        "limit": 5  # 少数のサンプルのみ
    }
    
    try:
        url = f"{base_url}/trigger"
        print(f"📡 サンプル収集開始: {url}")
        
        response = requests.post(url, headers=headers, json=sample_request, timeout=60)
        
        if response.status_code in [200, 201, 202]:
            print("✅ サンプル収集リクエスト成功!")
            
            try:
                result = response.json()
                snapshot_id = result.get("snapshot_id")
                if snapshot_id:
                    print(f"   スナップショットID: {snapshot_id}")
                    print("   ✅ データ収集機能が正常に動作しています")
                else:
                    print("   ⚠️  スナップショットIDが取得できませんでした")
            except:
                print("   ⚠️  レスポンスの解析に失敗しましたが、リクエストは成功しています")
            
            return True
            
        else:
            print(f"❌ サンプル収集エラー: HTTP {response.status_code}")
            print(f"   レスポンス: {response.text[:200]}...")
            return False
            
    except Exception as e:
        print(f"❌ サンプル収集テストエラー: {e}")
        return False

def test_google_sheets_setup(config):
    """Google Sheets設定テスト"""
    print("\n📊 Google Sheets設定テスト")
    print("-" * 40)
    
    credentials_file = config["google_sheets"]["credentials_file"]
    
    # 認証ファイル存在チェック
    if not os.path.exists(credentials_file):
        print(f"❌ Google認証ファイルが見つかりません: {credentials_file}")
        print("   Google Cloud Consoleから認証ファイルをダウンロードして配置してください")
        print("   詳細: https://console.cloud.google.com/apis/credentials")
        return False
    
    try:
        # 認証ファイル形式チェック
        with open(credentials_file, "r", encoding="utf-8") as f:
            creds = json.load(f)
        
        required_keys = ["type", "project_id", "client_email", "private_key"]
        missing_keys = [key for key in required_keys if key not in creds]
        
        if missing_keys:
            print(f"❌ 認証ファイルに必要なキーが不足: {missing_keys}")
            return False
        
        if creds.get("type") != "service_account":
            print("❌ サービスアカウント認証ファイルが必要です")
            return False
        
        print("✅ Google認証ファイル形式正常")
        print(f"   プロジェクトID: {creds.get('project_id')}")
        print(f"   サービスアカウント: {creds.get('client_email')}")
        
        # gspreadライブラリテスト
        try:
            import gspread
            from google.oauth2.service_account import Credentials
            
            # 認証テスト
            scope = [
                "https://spreadsheets.google.com/feeds",
                "https://www.googleapis.com/auth/drive"
            ]
            
            credentials = Credentials.from_service_account_file(credentials_file, scopes=scope)
            gc = gspread.authorize(credentials)
            
            print("✅ Google Sheets API認証成功")
            return True
            
        except ImportError:
            print("⚠️  gspreadライブラリがインストールされていません")
            print("   pip install gspread google-auth を実行してください")
            return False
            
        except Exception as e:
            print(f"❌ Google Sheets認証エラー: {e}")
            return False
            
    except json.JSONDecodeError:
        print("❌ 認証ファイルのJSON形式が正しくありません")
        return False
    except Exception as e:
        print(f"❌ 認証ファイル読み込みエラー: {e}")
        return False

def generate_test_report(results):
    """テスト結果レポート生成"""
    print("\n📋 テスト結果レポート")
    print("="*50)
    
    total_tests = len(results)
    passed_tests = sum(results.values())
    
    print(f"実行テスト数: {total_tests}")
    print(f"成功: {passed_tests}")
    print(f"失敗: {total_tests - passed_tests}")
    print(f"成功率: {passed_tests/total_tests*100:.1f}%")
    
    print("\n詳細結果:")
    for test_name, result in results.items():
        status = "✅ 成功" if result else "❌ 失敗"
        print(f"  {test_name}: {status}")
    
    if passed_tests == total_tests:
        print("\n🎉 全てのテストが成功しました!")
        print("   システムは正常に設定されています")
        print("   python main.py --method hybrid で実行を開始できます")
    else:
        print("\n⚠️  一部のテストが失敗しました")
        print("   上記のエラーメッセージを確認して設定を修正してください")
    
    # レポートファイル保存
    report_data = {
        "timestamp": datetime.now().isoformat(),
        "total_tests": total_tests,
        "passed_tests": passed_tests,
        "success_rate": passed_tests/total_tests*100,
        "results": results
    }
    
    try:
        with open("test_report.json", "w", encoding="utf-8") as f:
            json.dump(report_data, f, indent=2, ensure_ascii=False)
        print(f"\n📄 詳細レポートを保存しました: test_report.json")
    except Exception as e:
        print(f"⚠️  レポート保存エラー: {e}")

def main():
    """メイン関数"""
    print("🧪 TikTok Bright Data System - API接続テスト")
    print("="*60)
    print(f"実行時刻: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 設定ファイル読み込み
    config = load_config()
    if not config:
        sys.exit(1)
    
    # テスト実行
    results = {}
    
    # 1. Bright Data API接続テスト
    results["Bright Data API接続"] = test_bright_data_connection(config)
    
    # 2. サンプルデータ収集テスト（API接続が成功した場合のみ）
    if results["Bright Data API接続"]:
        results["サンプルデータ収集"] = test_sample_data_collection(config)
    else:
        results["サンプルデータ収集"] = False
        print("\n⏭️  API接続が失敗したため、サンプルデータ収集テストをスキップします")
    
    # 3. Google Sheets設定テスト
    results["Google Sheets設定"] = test_google_sheets_setup(config)
    
    # テスト結果レポート
    generate_test_report(results)
    
    return all(results.values())

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

