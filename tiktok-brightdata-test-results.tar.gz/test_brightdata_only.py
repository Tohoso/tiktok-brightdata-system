#!/usr/bin/env python3
"""
Bright Data API単体テスト
Google Sheetsを使わずにBright Data APIの動作確認
"""

import json
import requests
import time
from datetime import datetime

def load_config():
    """設定ファイル読み込み"""
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def test_bright_data_trigger():
    """Bright Data DCA APIトリガーテスト"""
    config = load_config()
    
    api_key = config["bright_data"]["api_key"]
    api_endpoint = config["bright_data"]["api_endpoint"]
    dataset_id = config["bright_data"]["dataset_id"]
    
    print("🧪 Bright Data DCA API テスト")
    print("=" * 50)
    print(f"API Endpoint: {api_endpoint}")
    print(f"Dataset ID: {dataset_id}")
    print(f"API Key: {api_key[:10]}...")
    
    # リクエストヘッダー
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    # テスト用リクエストデータ
    request_data = {
        "url": "https://www.tiktok.com/discover",
        "country": "JP",
        "format": "json"
    }
    
    # collectorをURLパラメータとして追加
    api_url_with_collector = f"{api_endpoint}?collector=c_l7q7dkf244hwjntr0"
    
    try:
        print("\n📡 API リクエスト送信中...")
        print(f"リクエストデータ: {json.dumps(request_data, indent=2)}")
        
        response = requests.post(
            api_url_with_collector,
            headers=headers,
            json=request_data,
            timeout=60
        )
        
        print(f"\n📊 レスポンス:")
        print(f"ステータスコード: {response.status_code}")
        print(f"ヘッダー: {dict(response.headers)}")
        
        if response.status_code == 200:
            try:
                result = response.json()
                print(f"✅ 成功! レスポンス: {json.dumps(result, indent=2)}")
                
                # スナップショットIDがあれば表示
                if "snapshot_id" in result:
                    snapshot_id = result["snapshot_id"]
                    print(f"\n🎯 スナップショットID: {snapshot_id}")
                    print("   データ収集が開始されました")
                    
                    # 結果取得のテスト
                    test_snapshot_status(api_key, snapshot_id)
                
                return True
                
            except json.JSONDecodeError:
                print(f"⚠️  JSONデコードエラー。レスポンステキスト: {response.text}")
                return False
                
        elif response.status_code == 401:
            print("❌ 認証エラー: APIキーが無効です")
            return False
            
        elif response.status_code == 400:
            print(f"❌ リクエストエラー: {response.text}")
            return False
            
        else:
            print(f"❌ APIエラー: HTTP {response.status_code}")
            print(f"レスポンス: {response.text}")
            return False
            
    except requests.exceptions.Timeout:
        print("❌ タイムアウトエラー")
        return False
        
    except requests.exceptions.ConnectionError:
        print("❌ 接続エラー")
        return False
        
    except Exception as e:
        print(f"❌ 予期しないエラー: {e}")
        return False

def test_snapshot_status(api_key: str, snapshot_id: str):
    """スナップショットステータス確認"""
    print(f"\n🔍 スナップショットステータス確認: {snapshot_id}")
    
    # ステータス確認用URL（推測）
    status_url = f"https://api.brightdata.com/dca/dataset/{snapshot_id}"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    try:
        response = requests.get(status_url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            try:
                status_data = response.json()
                print(f"✅ ステータス取得成功: {json.dumps(status_data, indent=2)}")
            except:
                print(f"⚠️  ステータス取得成功（JSON解析失敗）: {response.text}")
        else:
            print(f"⚠️  ステータス確認失敗: HTTP {response.status_code}")
            print(f"レスポンス: {response.text}")
            
    except Exception as e:
        print(f"⚠️  ステータス確認エラー: {e}")

def main():
    """メイン関数"""
    print("🚀 TikTok Bright Data System - API単体テスト")
    print(f"実行時刻: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    try:
        success = test_bright_data_trigger()
        
        if success:
            print("\n🎉 テスト成功!")
            print("   Bright Data APIが正常に動作しています")
        else:
            print("\n❌ テスト失敗")
            print("   設定やAPIキーを確認してください")
            
    except Exception as e:
        print(f"\n💥 テスト実行エラー: {e}")

if __name__ == "__main__":
    main()

