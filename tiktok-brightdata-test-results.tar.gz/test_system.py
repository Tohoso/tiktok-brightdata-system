#!/usr/bin/env python3
"""
TikTok Bright Data System - 統合テスト
全コンポーネントの動作確認とテスト
"""

import unittest
import json
import os
import tempfile
import sys
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, MagicMock

# テスト対象モジュールをインポート
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from brightdata_client import BrightDataClient
from sheets_manager import SheetsManager
from video_filter import VideoFilter
from main import TikTokBrightDataSystem

class TestBrightDataClient(unittest.TestCase):
    """Bright Data クライアントのテスト"""
    
    def setUp(self):
        """テスト前準備"""
        self.api_key = "test_api_key"
        self.dataset_id = "test_dataset_id"
        self.client = BrightDataClient(self.api_key, self.dataset_id)
    
    def test_initialization(self):
        """初期化テスト"""
        self.assertEqual(self.client.api_key, self.api_key)
        self.assertEqual(self.client.dataset_id, self.dataset_id)
        self.assertIsNotNone(self.client.session)
    
    @patch('requests.Session.post')
    def test_trigger_scraping_job(self, mock_post):
        """スクレイピングジョブ開始テスト"""
        # モックレスポンス設定
        mock_response = Mock()
        mock_response.json.return_value = {"snapshot_id": "test_snapshot_123"}
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response
        
        # テスト実行
        urls = ["https://www.tiktok.com/discover"]
        result = self.client.trigger_scraping_job(urls)
        
        # 検証
        self.assertEqual(result["snapshot_id"], "test_snapshot_123")
        mock_post.assert_called_once()
    
    @patch('requests.Session.get')
    def test_get_job_status(self, mock_get):
        """ジョブステータス取得テスト"""
        # モックレスポンス設定
        mock_response = Mock()
        mock_response.json.return_value = {"status": "completed"}
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        # テスト実行
        result = self.client.get_job_status("test_snapshot_123")
        
        # 検証
        self.assertEqual(result["status"], "completed")
        mock_get.assert_called_once()


class TestVideoFilter(unittest.TestCase):
    """動画フィルターのテスト"""
    
    def setUp(self):
        """テスト前準備"""
        self.config = {
            'min_views': 500000,
            'time_range_hours': 24,
            'exclude_verified': True,
            'languages': ['ja', 'jp'],
            'target_region': 'JP'
        }
        self.filter = VideoFilter(self.config)
    
    def test_initialization(self):
        """初期化テスト"""
        self.assertEqual(self.filter.min_views, 500000)
        self.assertEqual(self.filter.time_range_hours, 24)
        self.assertTrue(self.filter.exclude_verified)
    
    def test_time_filter_pass(self):
        """時間フィルター通過テスト"""
        video = {
            'create_time': datetime.now().isoformat(),
            'view_count': 1000000,
            'is_verified': False,
            'description': '今日の東京は暑いですね！ #東京'
        }
        
        passed, reason = self.filter._apply_filters(video)
        self.assertTrue(passed or reason != "time_range")
    
    def test_time_filter_fail(self):
        """時間フィルター除外テスト"""
        video = {
            'create_time': (datetime.now() - timedelta(hours=30)).isoformat(),
            'view_count': 1000000,
            'is_verified': False,
            'description': '昨日の東京 #東京'
        }
        
        passed, reason = self.filter._apply_filters(video)
        if not passed:
            self.assertEqual(reason, "time_range")
    
    def test_views_filter_pass(self):
        """再生数フィルター通過テスト"""
        self.assertTrue(self.filter._check_views_filter({'view_count': 1000000}))
        self.assertTrue(self.filter._check_views_filter({'view_count': '1.5M'}))
        self.assertTrue(self.filter._check_views_filter({'view_count': '800K'}))
    
    def test_views_filter_fail(self):
        """再生数フィルター除外テスト"""
        self.assertFalse(self.filter._check_views_filter({'view_count': 300000}))
        self.assertFalse(self.filter._check_views_filter({'view_count': '200K'}))
    
    def test_verified_filter(self):
        """認証済みフィルターテスト"""
        # 認証済みアカウント（除外）
        self.assertFalse(self.filter._check_verified_filter({'is_verified': True}))
        
        # 一般アカウント（通過）
        self.assertTrue(self.filter._check_verified_filter({'is_verified': False}))
    
    def test_japanese_score_calculation(self):
        """日本語スコア計算テスト"""
        # 日本語テキスト
        japanese_text = "今日の東京は暑いですね！"
        score = self.filter._calculate_japanese_score(japanese_text)
        self.assertGreater(score, 0.5)
        
        # 英語テキスト
        english_text = "Hello world!"
        score = self.filter._calculate_japanese_score(english_text)
        self.assertEqual(score, 0.0)
    
    def test_parse_count_string(self):
        """再生数文字列解析テスト"""
        self.assertEqual(self.filter._parse_count_string("1.5M"), 1500000)
        self.assertEqual(self.filter._parse_count_string("800K"), 800000)
        self.assertEqual(self.filter._parse_count_string("1000"), 1000)
        self.assertEqual(self.filter._parse_count_string("2.3B"), 2300000000)
    
    def test_filter_videos_integration(self):
        """動画フィルタリング統合テスト"""
        test_videos = [
            {
                'video_id': 'pass_001',
                'description': '今日の東京は暑い！ #東京 #日本',
                'view_count': 1000000,
                'create_time': datetime.now().isoformat(),
                'is_verified': False
            },
            {
                'video_id': 'fail_001',
                'description': 'Amazing Tokyo trip!',
                'view_count': 300000,  # 再生数不足
                'create_time': datetime.now().isoformat(),
                'is_verified': False
            },
            {
                'video_id': 'fail_002',
                'description': '昨日の大阪 #大阪',
                'view_count': 1000000,
                'create_time': (datetime.now() - timedelta(hours=30)).isoformat(),  # 時間超過
                'is_verified': False
            }
        ]
        
        filtered_videos, stats = self.filter.filter_videos(test_videos)
        
        # 1件のみ通過することを確認
        self.assertEqual(len(filtered_videos), 1)
        self.assertEqual(filtered_videos[0]['video_id'], 'pass_001')
        self.assertEqual(stats['total_input'], 3)
        self.assertEqual(stats['final_output'], 1)


class TestSheetsManager(unittest.TestCase):
    """Google Sheets マネージャーのテスト"""
    
    def setUp(self):
        """テスト前準備"""
        # モック認証情報ファイル作成
        self.temp_dir = tempfile.mkdtemp()
        self.credentials_file = os.path.join(self.temp_dir, "test_credentials.json")
        
        # ダミー認証情報
        dummy_credentials = {
            "type": "service_account",
            "project_id": "test-project",
            "private_key_id": "test-key-id",
            "private_key": "-----BEGIN PRIVATE KEY-----\ntest\n-----END PRIVATE KEY-----\n",
            "client_email": "test@test-project.iam.gserviceaccount.com",
            "client_id": "test-client-id",
            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
            "token_uri": "https://oauth2.googleapis.com/token"
        }
        
        with open(self.credentials_file, 'w') as f:
            json.dump(dummy_credentials, f)
    
    def tearDown(self):
        """テスト後クリーンアップ"""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    @patch('gspread.authorize')
    def test_initialization_mock(self, mock_authorize):
        """初期化テスト（モック）"""
        # モック設定
        mock_client = Mock()
        mock_spreadsheet = Mock()
        mock_client.open.return_value = mock_spreadsheet
        mock_authorize.return_value = mock_client
        
        # テスト実行
        sheets_manager = SheetsManager(self.credentials_file, "Test Spreadsheet")
        
        # 検証
        self.assertIsNotNone(sheets_manager.client)
        self.assertIsNotNone(sheets_manager.spreadsheet)
    
    def test_prepare_dataframe(self):
        """DataFrameの準備テスト"""
        # モック設定（認証をスキップ）
        with patch('gspread.authorize'):
            with patch.object(SheetsManager, '_authenticate'):
                sheets_manager = SheetsManager(self.credentials_file, "Test")
                
                # テストデータ
                test_data = [
                    {
                        'video_id': 'test_001',
                        'description': 'テスト動画',
                        'view_count': 1000000,
                        'like_count': 50000
                    }
                ]
                
                # DataFrame準備
                df = sheets_manager._prepare_dataframe(test_data)
                
                # 検証
                self.assertIn('動画ID', df.columns)
                self.assertIn('説明文', df.columns)
                self.assertIn('再生数', df.columns)
                self.assertEqual(len(df), 1)


class TestTikTokBrightDataSystem(unittest.TestCase):
    """メインシステムの統合テスト"""
    
    def setUp(self):
        """テスト前準備"""
        # テスト用設定ファイル作成
        self.temp_dir = tempfile.mkdtemp()
        self.config_file = os.path.join(self.temp_dir, "test_config.json")
        
        test_config = {
            "bright_data": {
                "api_key": "test_api_key",
                "dataset_id": "test_dataset_id",
                "timeout": 300
            },
            "google_sheets": {
                "credentials_file": "test_credentials.json",
                "spreadsheet_name": "Test Spreadsheet"
            },
            "collection_settings": {
                "min_views": 500000,
                "time_range_hours": 24,
                "exclude_verified": True,
                "languages": ["ja", "jp"],
                "target_region": "JP"
            },
            "output_settings": {
                "csv_output": True,
                "json_output": True
            },
            "logging": {
                "level": "INFO",
                "file": "test.log"
            }
        }
        
        with open(self.config_file, 'w') as f:
            json.dump(test_config, f)
    
    def tearDown(self):
        """テスト後クリーンアップ"""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    @patch.object(BrightDataClient, '__init__', return_value=None)
    @patch.object(SheetsManager, '__init__', return_value=None)
    @patch.object(VideoFilter, '__init__', return_value=None)
    def test_system_initialization(self, mock_filter, mock_sheets, mock_client):
        """システム初期化テスト"""
        # モック設定
        mock_filter.return_value = None
        mock_sheets.return_value = None
        mock_client.return_value = None
        
        # テスト実行
        system = TikTokBrightDataSystem(self.config_file)
        
        # 検証
        self.assertIsNotNone(system.config)
        self.assertEqual(system.config['bright_data']['api_key'], 'test_api_key')
    
    def test_config_loading(self):
        """設定ファイル読み込みテスト"""
        with patch.object(TikTokBrightDataSystem, '_initialize_components'):
            with patch.object(TikTokBrightDataSystem, '_setup_logging'):
                system = TikTokBrightDataSystem(self.config_file)
                
                # 設定値確認
                self.assertEqual(system.config['bright_data']['api_key'], 'test_api_key')
                self.assertEqual(system.config['collection_settings']['min_views'], 500000)
    
    def test_remove_duplicates(self):
        """重複除去テスト"""
        with patch.object(TikTokBrightDataSystem, '_initialize_components'):
            with patch.object(TikTokBrightDataSystem, '_setup_logging'):
                system = TikTokBrightDataSystem(self.config_file)
                
                # テストデータ（重複あり）
                videos = [
                    {'video_id': 'test_001', 'description': 'Video 1'},
                    {'video_id': 'test_002', 'description': 'Video 2'},
                    {'video_id': 'test_001', 'description': 'Video 1 Duplicate'},  # 重複
                    {'video_id': 'test_003', 'description': 'Video 3'}
                ]
                
                # 重複除去実行
                unique_videos = system._remove_duplicates(videos)
                
                # 検証
                self.assertEqual(len(unique_videos), 3)
                video_ids = [v['video_id'] for v in unique_videos]
                self.assertEqual(len(set(video_ids)), 3)  # 全てユニーク


class TestIntegration(unittest.TestCase):
    """統合テスト"""
    
    def test_end_to_end_mock(self):
        """エンドツーエンドテスト（モック使用）"""
        # モックデータ
        mock_videos = [
            {
                'video_id': 'test_001',
                'description': '今日の東京は暑い！ #東京',
                'view_count': 1000000,
                'like_count': 50000,
                'comment_count': 1000,
                'create_time': datetime.now().isoformat(),
                'is_verified': False,
                'author': {'followerCount': 5000}
            }
        ]
        
        # フィルタリングテスト
        config = {
            'min_views': 500000,
            'time_range_hours': 24,
            'exclude_verified': True,
            'languages': ['ja', 'jp'],
            'target_region': 'JP'
        }
        
        video_filter = VideoFilter(config)
        filtered_videos, stats = video_filter.filter_videos(mock_videos)
        
        # 検証
        self.assertEqual(len(filtered_videos), 1)
        self.assertGreater(stats['filter_rate'], 0)
        
        # 拡張データの確認
        enhanced_video = filtered_videos[0]
        self.assertIn('filtered_at', enhanced_video)
        self.assertIn('japanese_score', enhanced_video)
        self.assertIn('engagement_rate', enhanced_video)


def run_all_tests():
    """全テストを実行"""
    print("🧪 TikTok Bright Data System - 統合テスト実行")
    print("=" * 60)
    
    # テストスイート作成
    test_suite = unittest.TestSuite()
    
    # 各テストクラスを追加
    test_classes = [
        TestBrightDataClient,
        TestVideoFilter,
        TestSheetsManager,
        TestTikTokBrightDataSystem,
        TestIntegration
    ]
    
    for test_class in test_classes:
        tests = unittest.TestLoader().loadTestsFromTestCase(test_class)
        test_suite.addTests(tests)
    
    # テスト実行
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(test_suite)
    
    # 結果サマリー
    print("\n" + "=" * 60)
    print("📊 テスト結果サマリー")
    print(f"実行テスト数: {result.testsRun}")
    print(f"成功: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"失敗: {len(result.failures)}")
    print(f"エラー: {len(result.errors)}")
    
    if result.failures:
        print("\n❌ 失敗したテスト:")
        for test, traceback in result.failures:
            print(f"  - {test}")
    
    if result.errors:
        print("\n⚠️  エラーが発生したテスト:")
        for test, traceback in result.errors:
            print(f"  - {test}")
    
    if result.wasSuccessful():
        print("\n🎉 全テスト成功!")
        return True
    else:
        print("\n❌ テストに失敗があります")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)

