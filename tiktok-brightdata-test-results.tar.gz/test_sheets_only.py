#!/usr/bin/env python3
"""
Google Sheets API単体テスト
Bright Dataを使わずにGoogle Sheetsの動作確認
"""

import json
import gspread
from google.oauth2.service_account import Credentials
from datetime import datetime
import pandas as pd

def load_config():
    """設定ファイル読み込み"""
    with open("config.json", "r", encoding="utf-8") as f:
        return json.load(f)

def test_google_sheets_connection():
    """Google Sheets接続テスト"""
    config = load_config()
    
    print("🧪 Google Sheets API テスト")
    print("=" * 50)
    
    try:
        # 認証情報読み込み
        credentials_file = config["google_sheets"]["credentials_file"]
        spreadsheet_name = config["google_sheets"]["spreadsheet_name"]
        worksheet_name = config["google_sheets"]["worksheet_name"]
        
        print(f"認証ファイル: {credentials_file}")
        print(f"スプレッドシート名: {spreadsheet_name}")
        print(f"ワークシート名: {worksheet_name}")
        
        # Google Sheets API認証
        scope = [
            'https://spreadsheets.google.com/feeds',
            'https://www.googleapis.com/auth/drive'
        ]
        
        print("\n📡 Google認証中...")
        credentials = Credentials.from_service_account_file(
            credentials_file, 
            scopes=scope
        )
        
        gc = gspread.authorize(credentials)
        print("✅ Google認証成功")
        
        # スプレッドシート取得または作成
        print(f"\n📊 スプレッドシート操作: {spreadsheet_name}")
        
        try:
            spreadsheet = gc.open(spreadsheet_name)
            print("✅ 既存スプレッドシート取得成功")
        except gspread.SpreadsheetNotFound:
            print("⚠️  スプレッドシートが見つかりません。新規作成を試行...")
            spreadsheet = gc.create(spreadsheet_name)
            print("✅ 新規スプレッドシート作成成功")
        
        # ワークシート取得または作成
        print(f"\n📋 ワークシート操作: {worksheet_name}")
        
        try:
            worksheet = spreadsheet.worksheet(worksheet_name)
            print("✅ 既存ワークシート取得成功")
        except gspread.WorksheetNotFound:
            print("⚠️  ワークシートが見つかりません。新規作成を試行...")
            worksheet = spreadsheet.add_worksheet(
                title=worksheet_name,
                rows=1000,
                cols=20
            )
            print("✅ 新規ワークシート作成成功")
        
        # テストデータ作成
        test_data = create_test_data()
        
        # ヘッダー設定
        headers = list(test_data[0].keys())
        print(f"\n📝 ヘッダー設定: {headers}")
        
        # 既存データクリア（テスト用）
        worksheet.clear()
        
        # ヘッダー書き込み
        worksheet.append_row(headers)
        print("✅ ヘッダー書き込み成功")
        
        # テストデータ書き込み
        for i, row_data in enumerate(test_data):
            row_values = [str(row_data.get(header, "")) for header in headers]
            worksheet.append_row(row_values)
            print(f"✅ データ行 {i+1} 書き込み成功")
        
        # 書き込み結果確認
        all_values = worksheet.get_all_values()
        print(f"\n📊 書き込み結果確認:")
        print(f"   総行数: {len(all_values)}")
        print(f"   ヘッダー: {all_values[0] if all_values else 'なし'}")
        print(f"   データ行数: {len(all_values) - 1 if len(all_values) > 1 else 0}")
        
        # スプレッドシートURL取得
        spreadsheet_url = f"https://docs.google.com/spreadsheets/d/{spreadsheet.id}"
        print(f"\n🔗 スプレッドシートURL: {spreadsheet_url}")
        
        return True
        
    except Exception as e:
        print(f"❌ Google Sheetsテストエラー: {e}")
        return False

def create_test_data():
    """テスト用データ作成"""
    return [
        {
            "動画ID": "test_video_001",
            "作成者": "@test_user_1",
            "投稿日時": "2025-08-06 12:00:00",
            "再生数": "1,200,000",
            "いいね数": "45,000",
            "コメント数": "2,300",
            "シェア数": "8,900",
            "動画時間": "00:15",
            "説明文": "テスト動画1 #test #viral",
            "ハッシュタグ": "#test,#viral,#trending",
            "音楽": "Original Sound",
            "言語": "ja",
            "地域": "JP",
            "認証済み": "False",
            "投稿からの経過時間": "10.5",
            "エンゲージメント率": "4.2%",
            "動画URL": "https://www.tiktok.com/@test_user_1/video/test_video_001",
            "作成者URL": "https://www.tiktok.com/@test_user_1",
            "収集日時": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        },
        {
            "動画ID": "test_video_002",
            "作成者": "@test_user_2",
            "投稿日時": "2025-08-06 18:30:00",
            "再生数": "850,000",
            "いいね数": "32,000",
            "コメント数": "1,800",
            "シェア数": "5,600",
            "動画時間": "00:30",
            "説明文": "テスト動画2 #japan #funny",
            "ハッシュタグ": "#japan,#funny,#comedy",
            "音楽": "Trending Sound",
            "言語": "ja",
            "地域": "JP",
            "認証済み": "False",
            "投稿からの経過時間": "4.2",
            "エンゲージメント率": "4.5%",
            "動画URL": "https://www.tiktok.com/@test_user_2/video/test_video_002",
            "作成者URL": "https://www.tiktok.com/@test_user_2",
            "収集日時": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
    ]

def main():
    """メイン関数"""
    print("🚀 TikTok Bright Data System - Google Sheets単体テスト")
    print(f"実行時刻: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    try:
        success = test_google_sheets_connection()
        
        if success:
            print("\n🎉 Google Sheetsテスト成功!")
            print("   スプレッドシートへの書き込みが正常に動作しています")
        else:
            print("\n❌ Google Sheetsテスト失敗")
            print("   認証情報や設定を確認してください")
            
    except Exception as e:
        print(f"\n💥 テスト実行エラー: {e}")

if __name__ == "__main__":
    main()

